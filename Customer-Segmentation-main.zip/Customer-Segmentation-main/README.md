# Customer-Segmentation
Customer Segmentation using the K-Means algorithm in Python
<br> The link to the medium article published in 'Nerd for Tech': https://medium.com/@nehla99/customer-segmentation-using-python-e56c2b1a4c73 </br>
